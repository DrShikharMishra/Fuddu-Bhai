SR · MA · NMA 7-Day Teaching Batch (Researchmore Publications)
1_Lecture_Decks_PPTX      editable PowerPoint decks, one per day, with speaker notes
2_Lecture_Decks_PDF       same decks as PDF: open these on a phone
3_Notes_by_Day            notes PDF for each day + 00_Complete_Notes.pdf
4_Data_and_code           hypothetical dataset and the scripts that computed the worked examples
All datasets are hypothetical, for teaching only. Verify methods against the current Cochrane Handbook.
